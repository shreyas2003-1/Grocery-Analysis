
# Online Grocery Sales Analysis

This repository contains a Power BI report analyzing online grocery sales.

## Files
- **OnlineGrocerySales.pbix**: Power BI report file.

## How to Use
1. Open the `.pbix` file using Power BI Desktop.
2. Explore the visualizations and insights provided in the report.

## License
This project is open-source and available under the [MIT License](LICENSE).
